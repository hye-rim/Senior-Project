package com.onpuri;

/**
 * Created by kutemsys on 2016-07-25.
 */
public interface ChangedWordInterface {
    void changedData();
}
